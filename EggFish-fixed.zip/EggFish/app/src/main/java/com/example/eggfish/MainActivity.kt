package com.example.eggfish

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var tol: EditText
    private lateinit var mp: EditText
    private lateinit var cd: EditText
    private lateinit var cw: EditText
    private lateinit var ad: EditText
    private lateinit var ch: EditText

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Prefs.init(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
        }
        fun text(s: String) = TextView(this).apply { this.text = s; textSize = 14f; setPadding(0, 16, 0, 8) }
        fun field(label: String, v: Int): EditText {
            root.addView(text(label))
            return EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER
                setText(v.toString())
                root.addView(this)
            }
        }
        root.addView(TextView(this).apply { text = "EggFish 낚시 매크로"; textSize = 22f })
        root.addView(text(
            "1) 아래 버튼으로 접근성 설정을 열고 EggFish 서비스를 켜세요.\n" +
            "2) Roblox 화면에서 떠 있는 패널을 사용하세요.\n" +
            "   ▶/■ 시작·정지 / 영역 = 게이지 영역 드래그 / 색 = 게이지 색 탭 / 탭 = 클릭 위치 지정"))
        root.addView(Button(this).apply {
            text = "접근성 설정 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        val cast = CheckBox(this).apply {
            text = "던지기 사용 (길게 눌러 던지기)"
            isChecked = Prefs.castEnabled
            setOnCheckedChangeListener { _, v -> Prefs.castEnabled = v }
        }
        root.addView(cast)
        ch = field("던지기 누르는 시간 ms (기본 1000)", Prefs.castHold)
        tol = field("색 허용오차 (기본 20)", Prefs.tol)
        mp = field("게이지 최소 일치 픽셀 수 (기본 30, 오탐 많으면 올리기)", Prefs.minPx)
        cd = field("탭 간격 ms (기본 60)", Prefs.clickDelay)
        cw = field("게이지 대기 최대 ms (기본 4000)", Prefs.castWait)
        ad = field("낚시 후 대기 ms (기본 750)", Prefs.afterDelay)
        root.addView(Button(this).apply {
            text = "저장"
            setOnClickListener { save(); Toast.makeText(context, "저장됨", Toast.LENGTH_SHORT).show() }
        })
        setContentView(ScrollView(this).apply {
            addView(root, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        })
    }

    private fun save() {
        ch.text.toString().toIntOrNull()?.let { Prefs.castHold = it.coerceAtLeast(50) }
        tol.text.toString().toIntOrNull()?.let { Prefs.tol = it }
        mp.text.toString().toIntOrNull()?.let { Prefs.minPx = it.coerceAtLeast(1) }
        cd.text.toString().toIntOrNull()?.let { Prefs.clickDelay = it.coerceAtLeast(10) }
        cw.text.toString().toIntOrNull()?.let { Prefs.castWait = it }
        ad.text.toString().toIntOrNull()?.let { Prefs.afterDelay = it }
    }

    override fun onPause() { super.onPause(); save() }
}
