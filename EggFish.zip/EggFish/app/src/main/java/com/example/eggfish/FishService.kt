package com.example.eggfish

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.os.Handler
import android.os.Looper
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.*
import kotlin.coroutines.resume
import kotlin.math.abs

class FishService : AccessibilityService() {
    companion object { var instance: FishService? = null }

    private enum class Mode { REGION, COLOR, TAP }

    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val main = Handler(Looper.getMainLooper())
    private var job: Job? = null
    private lateinit var wm: WindowManager
    private var panel: LinearLayout? = null
    private var toggleBtn: Button? = null
    private var picker: View? = null

    override fun onServiceConnected() {
        instance = this
        Prefs.init(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stop()
        panel?.let { runCatching { wm.removeView(it) } }
        picker?.let { runCatching { wm.removeView(it) } }
        scope.cancel()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { stop() }

    private fun toast(s: String) = main.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    private fun bounds() = wm.currentWindowMetrics.bounds

    // ================= 플로팅 패널 =================
    private fun showPanel() {
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 300 }

        fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; textSize = 11f; minWidth = 0; minimumWidth = 0
            minHeight = 0; minimumHeight = 0; setPadding(16, 8, 16, 8)
            setOnClickListener { onClick() }
        }

        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            alpha = 0.85f
            setBackgroundColor(0x66000000)
        }
        // 드래그 핸들
        val handle = TextView(this).apply {
            text = "≡"; textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            var ox = 0f; var oy = 0f; var sx = 0; var sy = 0
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { ox = e.rawX; oy = e.rawY; sx = lp.x; sy = lp.y }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = sx + (e.rawX - ox).toInt(); lp.y = sy + (e.rawY - oy).toInt()
                        wm.updateViewLayout(p, lp)
                    }
                }
                true
            }
        }
        p.addView(handle)
        toggleBtn = btn("▶") { toggle() }
        p.addView(toggleBtn)
        p.addView(btn("영역") { startPicker(Mode.REGION) })
        p.addView(btn("색") { startPicker(Mode.COLOR) })
        p.addView(btn("탭") { startPicker(Mode.TAP) })
        panel = p
        wm.addView(p, lp)
    }

    // ================= 시작/정지 =================
    private fun toggle() {
        if (job?.isActive == true) stop() else start()
    }

    private fun start() {
        job = scope.launch { while (isActive) fishOnce() }
        main.post { toggleBtn?.text = "■" }
    }

    private fun stop() {
        job?.cancel(); job = null
        main.post { toggleBtn?.text = "▶" }
    }

    // ================= 낚시 로직 =================
    private suspend fun fishOnce() {
        tap()
        var waited = 0
        var seen = false
        while (waited < Prefs.castWait) {
            if (gaugeVisible()) { seen = true; break }
            delay(350); waited += 350
        }
        if (seen) {
            var last = System.currentTimeMillis()
            var visible = true
            while (visible) {
                tap()
                delay(Prefs.clickDelay.toLong())
                // 스크린샷은 약 0.33초에 한 번만 가능
                if (System.currentTimeMillis() - last >= 350) {
                    visible = gaugeVisible()
                    last = System.currentTimeMillis()
                }
            }
        }
        delay(Prefs.afterDelay.toLong())
    }

    private suspend fun gaugeVisible(): Boolean {
        val bmp = capture() ?: return false
        val w = bmp.width; val h = bmp.height
        val x1 = (Prefs.rl * w).toInt().coerceIn(0, w - 1)
        val x2 = (Prefs.rr * w).toInt().coerceIn(x1 + 1, w)
        val y1 = (Prefs.rt * h).toInt().coerceIn(0, h - 1)
        val y2 = (Prefs.rb * h).toInt().coerceIn(y1 + 1, h)
        val rw = x2 - x1; val rh = y2 - y1
        val px = IntArray(rw * rh)
        bmp.getPixels(px, 0, rw, x1, y1, rw, rh)
        bmp.recycle()
        val t = Prefs.color; val tol = Prefs.tol
        val tr = (t shr 16) and 255; val tg = (t shr 8) and 255; val tb = t and 255
        for (c in px) {
            if (abs(((c shr 16) and 255) - tr) <= tol &&
                abs(((c shr 8) and 255) - tg) <= tol &&
                abs((c and 255) - tb) <= tol) return true
        }
        return false
    }

    private suspend fun capture(): Bitmap? = suspendCancellableCoroutine { cont ->
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                val copy = hw?.copy(Bitmap.Config.ARGB_8888, false)
                hw?.recycle()
                r.hardwareBuffer.close()
                if (cont.isActive) cont.resume(copy)
            }
            override fun onFailure(code: Int) { if (cont.isActive) cont.resume(null) }
        })
    }

    private fun tap() {
        val b = bounds()
        val path = Path().apply { moveTo(Prefs.tapX * b.width(), Prefs.tapY * b.height()) }
        dispatchGesture(
            GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 20)).build(),
            null, null
        )
    }

    // ================= 측정 오버레이 =================
    private fun startPicker(mode: Mode) {
        stop()
        picker?.let { runCatching { wm.removeView(it) } }
        val b = bounds()
        val view = object : View(this) {
            var sx = 0f; var sy = 0f; var cx = 0f; var cy = 0f; var drag = false
            val paint = Paint().apply { color = Color.RED; style = Paint.Style.STROKE; strokeWidth = 4f }
            val tp = Paint().apply { color = Color.WHITE; textSize = 48f }
            override fun onDraw(c: Canvas) {
                c.drawColor(0x44000000)
                c.drawText(
                    when (mode) {
                        Mode.REGION -> "게이지 영역을 드래그하세요"
                        Mode.COLOR -> "게이지 색이 있는 곳을 탭하세요"
                        Mode.TAP -> "낚시 버튼(탭할 위치)을 탭하세요"
                    }, 40f, 150f, tp)
                if (drag) c.drawRect(minOf(sx, cx), minOf(sy, cy), maxOf(sx, cx), maxOf(sy, cy), paint)
            }
            override fun onTouchEvent(e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; cx = sx; cy = sy; drag = true }
                    MotionEvent.ACTION_MOVE -> { cx = e.rawX; cy = e.rawY }
                    MotionEvent.ACTION_UP -> {
                        cx = e.rawX; cy = e.rawY
                        finishPicker(mode, sx / b.width(), sy / b.height(), cx / b.width(), cy / b.height())
                    }
                }
                invalidate()
                return true
            }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        picker = view
        wm.addView(view, lp)
    }

    private fun finishPicker(mode: Mode, x1: Float, y1: Float, x2: Float, y2: Float) {
        picker?.let { runCatching { wm.removeView(it) } }
        picker = null
        when (mode) {
            Mode.REGION -> {
                if (abs(x2 - x1) < 0.01f || abs(y2 - y1) < 0.005f) { toast("영역이 너무 작아요"); return }
                Prefs.rl = minOf(x1, x2); Prefs.rr = maxOf(x1, x2)
                Prefs.rt = minOf(y1, y2); Prefs.rb = maxOf(y1, y2)
                toast("영역 저장됨")
            }
            Mode.TAP -> { Prefs.tapX = x2; Prefs.tapY = y2; toast("탭 위치 저장됨") }
            Mode.COLOR -> scope.launch {
                delay(300) // 오버레이가 사라진 뒤 캡처
                val bmp = capture()
                if (bmp == null) { toast("캡처 실패, 다시 시도하세요"); return@launch }
                val x = (x2 * bmp.width).toInt().coerceIn(0, bmp.width - 1)
                val y = (y2 * bmp.height).toInt().coerceIn(0, bmp.height - 1)
                val c = bmp.getPixel(x, y) and 0xFFFFFF
                bmp.recycle()
                Prefs.color = c
                toast("색 저장됨: #%06X".format(c))
            }
        }
    }
}
