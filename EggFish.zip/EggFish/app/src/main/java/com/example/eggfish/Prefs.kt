package com.example.eggfish

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) {
        if (!::sp.isInitialized)
            sp = c.applicationContext.getSharedPreferences("fish", Context.MODE_PRIVATE)
    }

    // 게이지 영역 (화면 비율 0~1)
    var rl: Float get() = sp.getFloat("rl", 0.26f); set(v) { sp.edit().putFloat("rl", v).apply() }
    var rt: Float get() = sp.getFloat("rt", 0.88f); set(v) { sp.edit().putFloat("rt", v).apply() }
    var rr: Float get() = sp.getFloat("rr", 0.70f); set(v) { sp.edit().putFloat("rr", v).apply() }
    var rb: Float get() = sp.getFloat("rb", 0.93f); set(v) { sp.edit().putFloat("rb", v).apply() }
    // 탭 위치 (화면 비율)
    var tapX: Float get() = sp.getFloat("tx", 0.5f); set(v) { sp.edit().putFloat("tx", v).apply() }
    var tapY: Float get() = sp.getFloat("ty", 0.5f); set(v) { sp.edit().putFloat("ty", v).apply() }
    // 색 / 허용오차 / 딜레이
    var color: Int get() = sp.getInt("color", 0xBDFE5B); set(v) { sp.edit().putInt("color", v and 0xFFFFFF).apply() }
    var tol: Int get() = sp.getInt("tol", 20); set(v) { sp.edit().putInt("tol", v).apply() }
    var clickDelay: Int get() = sp.getInt("cd", 60); set(v) { sp.edit().putInt("cd", v).apply() }
    var castWait: Int get() = sp.getInt("cw", 4000); set(v) { sp.edit().putInt("cw", v).apply() }
    var castEnabled: Boolean get() = sp.getBoolean("ce", true); set(v) { sp.edit().putBoolean("ce", v).apply() }
    var castHold: Int get() = sp.getInt("ch", 1000); set(v) { sp.edit().putInt("ch", v).apply() }
    var afterDelay: Int get() = sp.getInt("ad", 750); set(v) { sp.edit().putInt("ad", v).apply() }
}
