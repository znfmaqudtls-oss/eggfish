EggFish (Android 11+)
1. Android Studio로 이 폴더를 열기 -> Gradle Sync -> Run (또는 Build > Build APK)
2. 앱에서 [접근성 설정 열기] -> EggFish 켜기
3. Roblox 실행 후 떠 있는 패널 사용: 영역 / 색 / 탭 측정 -> ▶ 시작
